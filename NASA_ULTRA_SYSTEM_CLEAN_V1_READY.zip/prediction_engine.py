import random
class PredictionEngine:
    def combine(self,k,s):
        hot=k["hot_numbers"]
        base=list(range(1,38))
        result=set()
        while len(result)<3 and hot:
            result.add(random.choice(hot))
        while len(result)<6:
            result.add(random.choice(base))
        res=sorted(list(result))
        strong=random.randint(1,7)
        return {"main":res,"strong":strong}
