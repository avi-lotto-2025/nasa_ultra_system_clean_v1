import json
from history_loader import HistoryLoader
from kira_engine import KiraEngine
from prediction_engine import PredictionEngine
from stats_engine import StatsEngine

class EngineMaster:
    def __init__(self):
        self.history = HistoryLoader().load()
        self.kira = KiraEngine()
        self.stats = StatsEngine()
        self.prediction = PredictionEngine()

    def generate_forecast(self):
        kira_res = self.kira.analyze(self.history)
        stats_res = self.stats.process(self.history)
        forecast = self.prediction.combine(kira_res, stats_res)
        return {"forecast": forecast,"kira_patterns": kira_res,"stats": stats_res}
