class PackageEngine:
    def wrap(self,f): return f
