class StatsEngine:
    def process(self, history):
        cols={f"n{i}":[] for i in range(1,7)}
        for r in history:
            for k in cols: cols[k].append(r[k])
        avg={k: sum(v)/len(v) for k,v in cols.items()}
        return {"averages":avg,"count":len(history)}
