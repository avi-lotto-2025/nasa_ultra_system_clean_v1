class AutoHeal:
    def check(self): return {'status':'ok'}
