import statistics
class KiraEngine:
    def analyze(self, history):
        all_nums=[]
        for r in history:
            for k in ["n1","n2","n3","n4","n5","n6"]:
                all_nums.append(r[k])
        freq={}
        for n in all_nums: freq[n]=freq.get(n,0)+1
        avg=statistics.mean(freq.values())
        hot=[n for n,f in freq.items() if f>=avg*1.25]
        cold=[n for n,f in freq.items() if f<=avg*0.75]
        return {"freq":freq,"hot_numbers":hot,"cold_numbers":cold}
