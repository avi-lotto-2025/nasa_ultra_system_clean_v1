import random
class OfficialFetchEngine:
    def fetch(self): return {'draw':1,'numbers':[1,2,3,4,5,6],'strong':1}
