class EmailEngine:
    def send(self,f): return True
