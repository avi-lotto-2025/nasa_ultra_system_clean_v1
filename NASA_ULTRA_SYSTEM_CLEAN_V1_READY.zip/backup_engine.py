class BackupEngine:
    def save(self,f): return True
