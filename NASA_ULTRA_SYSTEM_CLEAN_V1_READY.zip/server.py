from flask import Flask, jsonify
from engine_master import EngineMaster
app=Flask(__name__)
engine=EngineMaster()
@app.route("/forecast")
def f(): return jsonify(engine.generate_forecast())
@app.route("/")
def h(): return jsonify({"status":"OK","endpoint":"/forecast"})
