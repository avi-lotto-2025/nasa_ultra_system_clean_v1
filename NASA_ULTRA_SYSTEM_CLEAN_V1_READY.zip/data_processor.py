class DataProcessor:
    def normalize(self,h): return h
