class DataProcessor:

    def clean(self, history):
        return history
